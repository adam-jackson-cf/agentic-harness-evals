import { render, screen, within } from "@testing-library/react";
import Home from "@/app/page";

const features = [
  "Lightning Fast",
  "Secure by Default",
  "Team Collaboration",
];

describe("Home page", () => {
  it("renders the header with logo and navigation links", () => {
    render(<Home />);

    expect(screen.getByText("Acme")).toBeInTheDocument();

    const nav = screen.getByRole("navigation");
    expect(within(nav).getByText("Home")).toBeInTheDocument();
    expect(within(nav).getByText("About")).toBeInTheDocument();
    expect(within(nav).getByText("Contact")).toBeInTheDocument();
  });

  it("renders the hero section with copy and call to action", () => {
    render(<Home />);

    expect(
      screen.getByRole("heading", { name: "Build Better Products Faster" })
    ).toBeInTheDocument();
    expect(
      screen.getByText(
        /Streamline your workflow with our all-in-one platform/i
      )
    ).toBeInTheDocument();
    expect(
      screen.getByRole("button", { name: "Get Started" })
    ).toBeInTheDocument();
  });

  it("renders three feature cards in the grid", () => {
    render(<Home />);

    features.forEach((feature) => {
      expect(
        screen.getByRole("heading", { name: feature })
      ).toBeInTheDocument();
    });
  });

  it("renders the footer copyright", () => {
    render(<Home />);

    expect(
      screen.getByText("© 2026 Acme. All rights reserved.")
    ).toBeInTheDocument();
  });
});
