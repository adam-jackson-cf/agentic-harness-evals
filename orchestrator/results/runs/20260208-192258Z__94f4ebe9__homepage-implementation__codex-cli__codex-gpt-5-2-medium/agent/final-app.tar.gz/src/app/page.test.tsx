import { render, screen } from "@testing-library/react";

import Home from "@/app/page";

describe("Home page", () => {
  it("renders the header navigation", () => {
    render(<Home />);

    expect(screen.getByRole("link", { name: "Home" })).toHaveAttribute(
      "href",
      "/"
    );
    expect(screen.getByRole("link", { name: "About" })).toHaveAttribute(
      "href",
      "/about"
    );
    expect(screen.getByRole("link", { name: "Contact" })).toHaveAttribute(
      "href",
      "/contact"
    );
  });

  it("renders the hero content and CTA", () => {
    render(<Home />);

    expect(
      screen.getByRole("heading", { name: /Build Better Products Faster/i })
    ).toBeInTheDocument();
    expect(
      screen.getByText(
        /Streamline your workflow with our all-in-one platform/i
      )
    ).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /Get Started/i })).toBeEnabled();
  });

  it("renders the features section", () => {
    render(<Home />);

    expect(
      screen.getByRole("heading", { name: /Everything You Need/i })
    ).toBeInTheDocument();
    expect(
      screen.getByRole("heading", { name: /Lightning Fast/i })
    ).toBeInTheDocument();
    expect(
      screen.getByRole("heading", { name: /Secure by Default/i })
    ).toBeInTheDocument();
    expect(
      screen.getByRole("heading", { name: /Team Collaboration/i })
    ).toBeInTheDocument();
  });

  it("renders the footer", () => {
    render(<Home />);

    expect(
      screen.getByText(/© 2026 Acme\. All rights reserved\./i)
    ).toBeInTheDocument();
  });
});
