import { Zap, ShieldCheck, Users } from "lucide-react";

import { Button } from "@/components/ui/button";

export type Feature = {
  title: string;
  description: string;
  Icon: typeof Zap;
};

const features: Feature[] = [
  {
    title: "Lightning Fast",
    description:
      "Deploy in seconds with our optimized infrastructure. No more waiting around.",
    Icon: Zap,
  },
  {
    title: "Secure by Default",
    description:
      "Enterprise-grade security with end-to-end encryption and compliance built in.",
    Icon: ShieldCheck,
  },
  {
    title: "Team Collaboration",
    description:
      "Work together in real-time with built-in collaboration tools and integrations.",
    Icon: Users,
  },
];

export default function Home() {
  return (
    <main className="min-h-screen bg-[var(--background)] text-[var(--foreground)]">
      <header className="border-b border-[var(--border)]">
        <div className="mx-auto flex w-full max-w-6xl items-center justify-between px-6 py-4">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-md bg-blue-100 text-[var(--primary)]">
              <Zap className="h-5 w-5" aria-hidden="true" />
            </div>
            <span className="text-lg font-semibold">Acme</span>
          </div>
          <nav className="flex items-center gap-8 text-sm font-medium text-[var(--muted)]">
            <a className="text-[var(--foreground)]" href="#home">
              Home
            </a>
            <a className="hover:text-[var(--foreground)]" href="#about">
              About
            </a>
            <a className="hover:text-[var(--foreground)]" href="#contact">
              Contact
            </a>
          </nav>
        </div>
      </header>

      <section
        id="home"
        className="mx-auto flex w-full max-w-4xl flex-col items-center px-6 py-24 text-center"
      >
        <h1 className="text-4xl font-semibold tracking-tight text-[var(--foreground)] md:text-5xl">
          Build Better Products Faster
        </h1>
        <p className="mt-4 max-w-2xl text-base text-[var(--muted)] md:text-lg">
          Streamline your workflow with our all-in-one platform. Ship features,
          track progress, and collaborate with your team seamlessly.
        </p>
        <Button className="mt-8 px-6 text-base">Get Started</Button>
      </section>

      <section
        id="about"
        className="border-t border-[var(--border)] bg-[#f9fafb]"
      >
        <div className="mx-auto w-full max-w-6xl px-6 py-20">
          <h2 className="text-center text-2xl font-semibold text-[var(--foreground)]">
            Everything You Need
          </h2>
          <div className="mt-10 grid gap-6 md:grid-cols-3">
            {features.map(({ title, description, Icon }) => (
              <article
                key={title}
                className="rounded-2xl border border-[var(--border)] bg-white p-6 shadow-sm"
              >
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-100 text-[var(--primary)]">
                  <Icon className="h-5 w-5" aria-hidden="true" />
                </div>
                <h3 className="mt-4 text-lg font-semibold text-[var(--foreground)]">
                  {title}
                </h3>
                <p className="mt-2 text-sm text-[var(--muted)]">
                  {description}
                </p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <footer
        id="contact"
        className="border-t border-[var(--border)] py-6 text-center text-sm text-[var(--muted)]"
      >
        © 2026 Acme. All rights reserved.
      </footer>
    </main>
  );
}
