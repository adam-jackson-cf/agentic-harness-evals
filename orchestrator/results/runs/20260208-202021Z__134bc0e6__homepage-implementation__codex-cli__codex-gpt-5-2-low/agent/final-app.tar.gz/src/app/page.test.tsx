import { render, screen, within } from "@testing-library/react";

import Home from "@/app/page";

describe("Home page", () => {
  test("renders header with logo and navigation links", () => {
    render(<Home />);

    const banner = screen.getByRole("banner");
    expect(within(banner).getByText("Acme")).toBeInTheDocument();
    expect(within(banner).getByRole("link", { name: "Home" })).toHaveAttribute(
      "href",
      "#home",
    );
    expect(within(banner).getByRole("link", { name: "About" })).toHaveAttribute(
      "href",
      "#about",
    );
    expect(
      within(banner).getByRole("link", { name: "Contact" }),
    ).toHaveAttribute("href", "#contact");
  });

  test("renders hero section with call to action", () => {
    render(<Home />);

    expect(
      screen.getByRole("heading", { name: "Build Better Products Faster" }),
    ).toBeInTheDocument();
    expect(
      screen.getByText(
        /Streamline your workflow with our all-in-one platform/i,
      ),
    ).toBeInTheDocument();
    expect(
      screen.getByRole("button", { name: "Get Started" }),
    ).toBeInTheDocument();
  });

  test("renders features grid with three cards", () => {
    render(<Home />);

    const headings = [
      "Lightning Fast",
      "Secure by Default",
      "Team Collaboration",
    ];

    headings.forEach((title) => {
      expect(screen.getByRole("heading", { name: title })).toBeInTheDocument();
    });

    const featureCards = screen.getAllByRole("article");
    expect(featureCards).toHaveLength(3);
  });

  test("renders footer copyright", () => {
    render(<Home />);

    const contentInfo = screen.getByRole("contentinfo");
    expect(contentInfo).toHaveTextContent(
      "© 2026 Acme. All rights reserved.",
    );
  });
});
