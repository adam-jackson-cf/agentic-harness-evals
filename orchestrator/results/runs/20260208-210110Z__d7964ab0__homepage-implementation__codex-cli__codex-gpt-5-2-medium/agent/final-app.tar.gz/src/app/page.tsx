import { Bolt, Lock, Users } from "lucide-react";

import { FeatureCard, type Feature } from "@/components/feature-card";
import { Button } from "@/components/ui/button";

const features: Feature[] = [
  {
    title: "Lightning Fast",
    description: "Deploy in seconds with our optimized infrastructure. No more waiting around.",
    icon: Bolt,
  },
  {
    title: "Secure by Default",
    description:
      "Enterprise-grade security with end-to-end encryption and compliance built in.",
    icon: Lock,
  },
  {
    title: "Team Collaboration",
    description:
      "Work together in real-time with built-in collaboration tools and integrations.",
    icon: Users,
  },
];

export default function Home() {
  return (
    <div className="min-h-screen bg-[var(--background)] text-[var(--foreground)]">
      <header className="border-b border-[var(--border)]">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-5">
          <div className="flex items-center gap-2 text-lg font-semibold">
            <span className="inline-flex h-9 w-9 items-center justify-center rounded-lg bg-[color:color-mix(in_srgb,var(--primary)_12%,var(--background))]">
              <Bolt className="h-5 w-5 text-[var(--primary)]" aria-hidden="true" />
            </span>
            <span>Acme</span>
          </div>
          <nav aria-label="Primary">
            <ul className="flex items-center gap-6 text-sm font-medium text-[var(--muted)]">
              <li>
                <a className="transition hover:text-[var(--foreground)]" href="#home">
                  Home
                </a>
              </li>
              <li>
                <a className="transition hover:text-[var(--foreground)]" href="#about">
                  About
                </a>
              </li>
              <li>
                <a className="transition hover:text-[var(--foreground)]" href="#contact">
                  Contact
                </a>
              </li>
            </ul>
          </nav>
        </div>
      </header>

      <main>
        <section className="px-6 py-20 text-center" id="home">
          <div className="mx-auto flex max-w-3xl flex-col items-center gap-6">
            <h1 className="text-4xl font-semibold tracking-tight sm:text-5xl">
              Build Better Products Faster
            </h1>
            <p className="text-base text-[var(--muted)] sm:text-lg">
              Streamline your workflow with our all-in-one platform. Ship features,
              track progress, and collaborate with your team seamlessly.
            </p>
            <Button className="h-11 px-8 text-base">Get Started</Button>
          </div>
        </section>

        <section
          className="border-t border-[var(--border)] bg-[var(--background)] px-6 py-16"
          id="about"
        >
          <div className="mx-auto flex max-w-6xl flex-col items-center gap-10">
            <div className="text-center">
              <h2 className="text-2xl font-semibold">Everything You Need</h2>
              <p className="mt-2 text-sm text-[var(--muted)]">
                Powerful tooling designed to help modern teams deliver exceptional
                products.
              </p>
            </div>
            <div className="grid w-full gap-6 md:grid-cols-3">
              {features.map((feature) => (
                <FeatureCard key={feature.title} feature={feature} />
              ))}
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-[var(--border)] px-6 py-6" id="contact">
        <div className="mx-auto max-w-6xl text-center text-sm text-[var(--muted)]">
          © 2026 Acme. All rights reserved.
        </div>
      </footer>
    </div>
  );
}
