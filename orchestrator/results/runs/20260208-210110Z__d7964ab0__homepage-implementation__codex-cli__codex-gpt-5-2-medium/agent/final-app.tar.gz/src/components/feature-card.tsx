import type { LucideIcon } from "lucide-react";

export type Feature = {
  title: string;
  description: string;
  icon: LucideIcon;
};

type FeatureCardProps = {
  feature: Feature;
};

export function FeatureCard({ feature }: FeatureCardProps) {
  const Icon = feature.icon;

  return (
    <article className="rounded-xl border border-[var(--border)] bg-[var(--background)] p-6 shadow-sm">
      <div className="mb-4 inline-flex h-10 w-10 items-center justify-center rounded-lg bg-[color:color-mix(in_srgb,var(--primary)_12%,var(--background))]">
        <Icon aria-hidden="true" className="h-5 w-5 text-[var(--primary)]" />
      </div>
      <h3 className="text-lg font-semibold text-[var(--foreground)]">
        {feature.title}
      </h3>
      <p className="mt-2 text-sm leading-relaxed text-[var(--muted)]">
        {feature.description}
      </p>
    </article>
  );
}
