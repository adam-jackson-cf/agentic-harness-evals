import { render, screen, within } from "@testing-library/react";

import Home from "@/app/page";

describe("Home page", () => {
  it("renders the header navigation links", () => {
    render(<Home />);

    expect(screen.getByRole("link", { name: "Home" })).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "About" })).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "Contact" })).toBeInTheDocument();
  });

  it("renders the hero content and CTA", () => {
    render(<Home />);

    expect(
      screen.getByRole("heading", {
        name: "Build Better Products Faster",
        level: 1,
      })
    ).toBeInTheDocument();
    expect(
      screen.getByText(
        /Streamline your workflow with our all-in-one platform/i
      )
    ).toBeInTheDocument();
    expect(
      screen.getByRole("button", { name: "Get Started" })
    ).toBeInTheDocument();
  });

  it("shows three feature cards", () => {
    render(<Home />);

    const sectionHeading = screen.getByRole("heading", {
      name: "Everything You Need",
      level: 2,
    });
    const section = sectionHeading.closest("section");

    expect(section).not.toBeNull();

    const cards = within(section as HTMLElement).getAllByRole("article");
    expect(cards).toHaveLength(3);
  });

  it("renders footer copyright", () => {
    render(<Home />);

    const year = new Date().getFullYear();
    expect(
      screen.getByText(`(c) ${year} Acme. All rights reserved.`)
    ).toBeInTheDocument();
  });
});
