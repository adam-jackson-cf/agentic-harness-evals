import Link from "next/link";
import { Shield, Users, Zap } from "lucide-react";

import { Button } from "@/components/ui/button";

const features = [
  {
    title: "Lightning Fast",
    description:
      "Deploy in seconds with our optimized infrastructure. No more waiting around.",
    icon: Zap,
  },
  {
    title: "Secure by Default",
    description:
      "Enterprise-grade security with end-to-end encryption and compliance built in.",
    icon: Shield,
  },
  {
    title: "Team Collaboration",
    description:
      "Work together in real-time with built-in collaboration tools and integrations.",
    icon: Users,
  },
] as const;

export default function Home() {
  return (
    <main className="min-h-screen bg-[var(--background)] text-[var(--foreground)]">
      <header className="border-b border-[var(--border)]">
        <div className="mx-auto flex w-full max-w-6xl items-center justify-between px-6 py-4">
          <div className="flex items-center gap-2 text-lg font-semibold">
            <Zap className="h-5 w-5 text-[var(--primary)]" aria-hidden="true" />
            <span>Acme</span>
          </div>
          <nav className="flex items-center gap-6 text-sm font-medium text-[var(--muted)]">
            <Link className="transition-colors hover:text-[var(--foreground)]" href="#">
              Home
            </Link>
            <Link className="transition-colors hover:text-[var(--foreground)]" href="#">
              About
            </Link>
            <Link className="transition-colors hover:text-[var(--foreground)]" href="#">
              Contact
            </Link>
          </nav>
        </div>
      </header>

      <section className="mx-auto flex w-full max-w-4xl flex-col items-center px-6 py-20 text-center">
        <p className="mb-4 text-sm font-semibold uppercase tracking-[0.25em] text-[var(--muted)]">
          Acme platform
        </p>
        <h1 className="text-balance text-4xl font-semibold tracking-tight text-[var(--foreground)] sm:text-5xl">
          Build Better Products Faster
        </h1>
        <p className="mt-4 max-w-2xl text-balance text-base text-[var(--muted)] sm:text-lg">
          Streamline your workflow with our all-in-one platform. Ship features,
          track progress, and collaborate with your team seamlessly.
        </p>
        <Button className="mt-8" size="lg">
          Get Started
        </Button>
      </section>

      <section className="border-t border-[var(--border)] bg-[var(--background)]">
        <div className="mx-auto w-full max-w-6xl px-6 py-16">
          <div className="text-center">
            <p className="text-sm font-semibold uppercase tracking-[0.25em] text-[var(--muted)]">
              Features
            </p>
            <h2 className="mt-3 text-2xl font-semibold text-[var(--foreground)] sm:text-3xl">
              Everything You Need
            </h2>
          </div>
          <div className="mt-10 grid gap-6 md:grid-cols-3">
            {features.map((feature) => {
              const Icon = feature.icon;
              return (
                <article
                  className="rounded-2xl border border-[var(--border)] bg-[var(--background)] p-6 shadow-sm"
                  key={feature.title}
                >
                  <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-[rgba(37,99,235,0.1)] text-[var(--primary)]">
                    <Icon className="h-5 w-5" aria-hidden="true" />
                  </div>
                  <h3 className="mt-4 text-lg font-semibold text-[var(--foreground)]">
                    {feature.title}
                  </h3>
                  <p className="mt-2 text-sm text-[var(--muted)]">
                    {feature.description}
                  </p>
                </article>
              );
            })}
          </div>
        </div>
      </section>

      <footer className="border-t border-[var(--border)]">
        <div className="mx-auto w-full max-w-6xl px-6 py-6 text-center text-sm text-[var(--muted)]">
          (c) {new Date().getFullYear()} Acme. All rights reserved.
        </div>
      </footer>
    </main>
  );
}
