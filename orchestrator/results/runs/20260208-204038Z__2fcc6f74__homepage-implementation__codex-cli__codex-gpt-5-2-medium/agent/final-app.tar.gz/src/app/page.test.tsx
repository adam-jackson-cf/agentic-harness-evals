import { render, screen } from "@testing-library/react";

import Home from "@/app/page";

describe("Home page", () => {
  it("renders the header with logo and navigation links", () => {
    render(<Home />);

    expect(screen.getByText("Acme")).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "Home" })).toHaveAttribute(
      "href",
      "#home"
    );
    expect(screen.getByRole("link", { name: "About" })).toHaveAttribute(
      "href",
      "#about"
    );
    expect(screen.getByRole("link", { name: "Contact" })).toHaveAttribute(
      "href",
      "#contact"
    );
  });

  it("renders the hero section with CTA", () => {
    render(<Home />);

    expect(
      screen.getByRole("heading", {
        level: 1,
        name: "Build Better Products Faster",
      })
    ).toBeInTheDocument();
    expect(
      screen.getByText(
        /Streamline your workflow with our all-in-one platform/i
      )
    ).toBeInTheDocument();
    expect(
      screen.getByRole("button", { name: "Get Started" })
    ).toBeInTheDocument();
  });

  it("renders the features grid", () => {
    render(<Home />);

    expect(
      screen.getByRole("heading", { level: 2, name: "Everything You Need" })
    ).toBeInTheDocument();
    expect(
      screen.getByRole("heading", { level: 3, name: "Lightning Fast" })
    ).toBeInTheDocument();
    expect(
      screen.getByRole("heading", { level: 3, name: "Secure by Default" })
    ).toBeInTheDocument();
    expect(
      screen.getByRole("heading", { level: 3, name: "Team Collaboration" })
    ).toBeInTheDocument();
  });

  it("renders the footer with copyright text", () => {
    render(<Home />);

    const year = new Date().getFullYear();
    expect(
      screen.getByText(`© ${year} Acme. All rights reserved.`)
    ).toBeInTheDocument();
  });
});
