import { ShieldCheck, Users, Zap } from "lucide-react";

import { Button } from "@/components/ui/button";

const features = [
  {
    title: "Lightning Fast",
    description:
      "Deploy in seconds with our optimized infrastructure. No more waiting around.",
    icon: Zap,
  },
  {
    title: "Secure by Default",
    description:
      "Enterprise-grade security with end-to-end encryption and compliance built in.",
    icon: ShieldCheck,
  },
  {
    title: "Team Collaboration",
    description:
      "Work together in real-time with built-in collaboration tools and integrations.",
    icon: Users,
  },
];

const navLinks = [
  { label: "Home", href: "#home" },
  { label: "About", href: "#about" },
  { label: "Contact", href: "#contact" },
];

export default function Home() {
  return (
    <div className="min-h-screen bg-[var(--background)] text-[var(--foreground)]">
      <header className="border-b border-[var(--border)]">
        <div className="mx-auto flex w-full max-w-6xl items-center justify-between px-6 py-4">
          <div className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-[var(--border)] text-[var(--primary)]">
              <Zap className="h-5 w-5" aria-hidden="true" />
            </div>
            <span className="text-lg font-semibold">Acme</span>
          </div>
          <nav className="flex items-center gap-8 text-sm font-medium">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="text-[var(--muted)] transition-colors hover:text-[var(--foreground)]"
              >
                {link.label}
              </a>
            ))}
          </nav>
        </div>
      </header>

      <main className="flex flex-col">
        <section id="home" className="px-6 py-20">
          <div className="mx-auto flex w-full max-w-3xl flex-col items-center gap-6 text-center">
            <h1 className="text-balance text-4xl font-semibold tracking-tight sm:text-5xl">
              Build Better Products Faster
            </h1>
            <p className="text-balance text-base text-[var(--muted)] sm:text-lg">
              Streamline your workflow with our all-in-one platform. Ship features,
              track progress, and collaborate with your team seamlessly.
            </p>
            <Button size="lg">Get Started</Button>
          </div>
        </section>

        <section id="about" className="border-t border-[var(--border)] px-6 py-16">
          <div className="mx-auto flex w-full max-w-6xl flex-col gap-10">
            <div className="text-center">
              <h2 className="text-2xl font-semibold">Everything You Need</h2>
            </div>
            <div className="grid gap-6 md:grid-cols-3">
              {features.map((feature) => {
                const Icon = feature.icon;
                return (
                  <article
                    key={feature.title}
                    className="rounded-2xl border border-[var(--border)] bg-[var(--background)] p-6 shadow-sm"
                  >
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-[var(--border)] text-[var(--primary)]">
                      <Icon className="h-5 w-5" aria-hidden="true" />
                    </div>
                    <h3 className="mt-4 text-lg font-semibold">
                      {feature.title}
                    </h3>
                    <p className="mt-2 text-sm text-[var(--muted)]">
                      {feature.description}
                    </p>
                  </article>
                );
              })}
            </div>
          </div>
        </section>
      </main>

      <footer
        id="contact"
        className="border-t border-[var(--border)] px-6 py-6"
      >
        <div className="mx-auto flex w-full max-w-6xl justify-center text-sm text-[var(--muted)]">
          © {new Date().getFullYear()} Acme. All rights reserved.
        </div>
      </footer>
    </div>
  );
}
