import { ShieldCheck, Users, Zap } from "lucide-react";

import { Button } from "@/components/ui/button";

const features = [
  {
    title: "Lightning Fast",
    description:
      "Deploy in seconds with our optimized infrastructure. No more waiting around.",
    icon: Zap,
  },
  {
    title: "Secure by Default",
    description:
      "Enterprise-grade security with end-to-end encryption and compliance built in.",
    icon: ShieldCheck,
  },
  {
    title: "Team Collaboration",
    description:
      "Work together in real-time with built-in collaboration tools and integrations.",
    icon: Users,
  },
] as const;

const navigation = [
  { label: "Home", href: "#home" },
  { label: "About", href: "#about" },
  { label: "Contact", href: "#contact" },
] as const;

export default function Home() {
  const year = new Date().getFullYear();

  return (
    <main className="min-h-screen bg-[var(--background)] text-[color:var(--foreground)]">
      <header className="border-b border-[var(--border)]">
        <div className="mx-auto flex w-full max-w-6xl items-center justify-between px-6 py-4">
          <div className="flex items-center gap-2 text-lg font-semibold">
            <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-[color:color-mix(in_srgb,var(--primary),#ffffff_80%)] text-[color:var(--primary)]">
              <Zap className="h-5 w-5" aria-hidden="true" />
            </span>
            <span>Acme</span>
          </div>
          <nav className="flex items-center gap-6 text-sm font-medium text-[color:var(--muted)]">
            {navigation.map((item) => (
              <a
                key={item.label}
                href={item.href}
                className="transition-colors hover:text-[color:var(--foreground)]"
              >
                {item.label}
              </a>
            ))}
          </nav>
        </div>
      </header>

      <section id="home" className="mx-auto flex max-w-4xl flex-col items-center px-6 py-20 text-center">
        <p className="text-sm font-semibold uppercase tracking-[0.2em] text-[color:var(--muted)]">
          Launch with confidence
        </p>
        <h1 className="mt-5 text-4xl font-semibold leading-tight text-[color:var(--foreground)] sm:text-5xl">
          Build Better Products Faster
        </h1>
        <p className="mt-4 text-base leading-relaxed text-[color:var(--muted)] sm:text-lg">
          Streamline your workflow with our all-in-one platform. Ship features, track progress,
          and collaborate with your team seamlessly.
        </p>
        <Button className="mt-8 px-7">Get Started</Button>
      </section>

      <section
        id="about"
        className="bg-[color:color-mix(in_srgb,var(--background),#000_3%)] py-16"
      >
        <div className="mx-auto flex w-full max-w-6xl flex-col items-center px-6">
          <h2 className="text-3xl font-semibold text-[color:var(--foreground)]">
            Everything You Need
          </h2>
          <p className="mt-3 text-center text-sm text-[color:var(--muted)] sm:text-base">
            The core tools your team needs to plan, build, and scale with confidence.
          </p>
          <div className="mt-10 grid w-full gap-6 md:grid-cols-3">
            {features.map((feature) => (
              <div
                key={feature.title}
                className="rounded-2xl border border-[var(--border)] bg-[var(--background)] p-6 shadow-sm"
              >
                <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-[color:color-mix(in_srgb,var(--primary),#ffffff_82%)] text-[color:var(--primary)]">
                  <feature.icon className="h-5 w-5" aria-hidden="true" />
                </span>
                <h3 className="mt-5 text-lg font-semibold text-[color:var(--foreground)]">
                  {feature.title}
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-[color:var(--muted)]">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <footer
        id="contact"
        className="border-t border-[var(--border)] py-6 text-center text-sm text-[color:var(--muted)]"
      >
        © {year} Acme. All rights reserved.
      </footer>
    </main>
  );
}
