import Link from "next/link";
import { ShieldCheck, Users, Zap } from "lucide-react";

import { Button } from "@/components/ui/button";

const features = [
  {
    title: "Lightning Fast",
    description:
      "Deploy in seconds with our optimized infrastructure. No more waiting around.",
    icon: Zap,
  },
  {
    title: "Secure by Default",
    description:
      "Enterprise-grade security with end-to-end encryption and compliance built in.",
    icon: ShieldCheck,
  },
  {
    title: "Team Collaboration",
    description:
      "Work together in real-time with built-in collaboration tools and integrations.",
    icon: Users,
  },
] as const;

export default function Home() {
  const currentYear = new Date().getFullYear();

  return (
    <div className="min-h-screen bg-[color:var(--background)] text-[color:var(--foreground)]">
      <header className="border-b border-[color:var(--border)]">
        <div className="mx-auto flex w-full max-w-6xl items-center justify-between px-6 py-5">
          <div className="flex items-center gap-2 text-lg font-semibold">
            <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-[color:var(--primary)]/10">
              <Zap
                className="h-4 w-4 text-[color:var(--primary)]"
                aria-hidden="true"
              />
            </span>
            <span>Acme</span>
          </div>
          <nav className="flex items-center gap-6 text-sm font-medium text-[color:var(--muted)]">
            <Link
              className="transition-colors hover:text-[color:var(--foreground)]"
              href="#home"
            >
              Home
            </Link>
            <Link
              className="transition-colors hover:text-[color:var(--foreground)]"
              href="#about"
            >
              About
            </Link>
            <Link
              className="transition-colors hover:text-[color:var(--foreground)]"
              href="#contact"
            >
              Contact
            </Link>
          </nav>
        </div>
      </header>

      <main className="flex-1">
        <section
          id="home"
          className="mx-auto flex w-full max-w-5xl flex-col items-center px-6 py-20 text-center"
        >
          <h1 className="text-balance text-4xl font-semibold tracking-tight sm:text-5xl">
            Build Better Products Faster
          </h1>
          <p className="mt-5 max-w-2xl text-pretty text-base text-[color:var(--muted)] sm:text-lg">
            Streamline your workflow with our all-in-one platform. Ship features,
            track progress, and collaborate with your team seamlessly.
          </p>
          <div className="mt-8">
            <Button size="lg">Get Started</Button>
          </div>
        </section>

        <section
          id="about"
          className="border-t border-[color:var(--border)] bg-[color:var(--background)]"
        >
          <div className="mx-auto w-full max-w-6xl px-6 py-16">
            <div className="text-center">
              <h2 className="text-2xl font-semibold sm:text-3xl">
                Everything You Need
              </h2>
              <p className="mt-3 text-sm text-[color:var(--muted)] sm:text-base">
                A modern toolkit built to help your team stay focused and ship
                faster.
              </p>
            </div>
            <div className="mt-10 grid gap-6 md:grid-cols-3">
              {features.map((feature) => {
                const Icon = feature.icon;

                return (
                  <div
                    key={feature.title}
                    className="rounded-xl border border-[color:var(--border)] bg-[color:var(--background)] p-6 shadow-sm"
                  >
                    <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-[color:var(--primary)]/10">
                      <Icon
                        className="h-5 w-5 text-[color:var(--primary)]"
                        aria-hidden="true"
                      />
                    </div>
                    <h3 className="mt-5 text-lg font-semibold">
                      {feature.title}
                    </h3>
                    <p className="mt-2 text-sm text-[color:var(--muted)]">
                      {feature.description}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        </section>
      </main>

      <footer
        id="contact"
        className="border-t border-[color:var(--border)]"
      >
        <div className="mx-auto w-full max-w-6xl px-6 py-8 text-center text-sm text-[color:var(--muted)]">
          © {currentYear} Acme. All rights reserved.
        </div>
      </footer>
    </div>
  );
}
