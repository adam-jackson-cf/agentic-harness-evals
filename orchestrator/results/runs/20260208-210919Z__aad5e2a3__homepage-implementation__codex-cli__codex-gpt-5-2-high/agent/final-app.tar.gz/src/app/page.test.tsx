import { render, screen } from "@testing-library/react";

import Home from "@/app/page";

describe("Home page", () => {
  it("renders the header with logo and navigation links", () => {
    render(<Home />);

    expect(screen.getByText("Acme")).toBeInTheDocument();

    const homeLink = screen.getByRole("link", { name: "Home" });
    const aboutLink = screen.getByRole("link", { name: "About" });
    const contactLink = screen.getByRole("link", { name: "Contact" });

    expect(homeLink).toHaveAttribute("href", "#home");
    expect(aboutLink).toHaveAttribute("href", "#about");
    expect(contactLink).toHaveAttribute("href", "#contact");
  });

  it("renders the hero content and call to action", () => {
    render(<Home />);

    expect(
      screen.getByRole("heading", {
        level: 1,
        name: /build better products faster/i,
      })
    ).toBeInTheDocument();
    expect(
      screen.getByText(/streamline your workflow with our all-in-one platform/i)
    ).toBeInTheDocument();
    expect(
      screen.getByRole("button", { name: /get started/i })
    ).toBeInTheDocument();
  });

  it("renders the features section with three feature cards", () => {
    render(<Home />);

    expect(
      screen.getByRole("heading", { level: 2, name: /everything you need/i })
    ).toBeInTheDocument();

    const featureHeadings = screen.getAllByRole("heading", { level: 3 });
    expect(featureHeadings).toHaveLength(3);

    expect(screen.getByText("Lightning Fast")).toBeInTheDocument();
    expect(screen.getByText("Secure by Default")).toBeInTheDocument();
    expect(screen.getByText("Team Collaboration")).toBeInTheDocument();
  });

  it("renders the footer with the current year", () => {
    render(<Home />);

    const year = new Date().getFullYear();
    expect(
      screen.getByText(new RegExp(`© ${year} Acme`, "i"))
    ).toBeInTheDocument();
  });
});
