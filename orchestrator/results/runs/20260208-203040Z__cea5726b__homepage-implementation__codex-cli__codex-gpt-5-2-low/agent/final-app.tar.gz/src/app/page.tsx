import { ShieldCheck, Sparkles, Users } from "lucide-react";

import { Button } from "@/components/ui/button";

const features = [
  {
    title: "Lightning Fast",
    description:
      "Deploy in seconds with our optimized infrastructure. No more waiting around.",
    icon: Sparkles,
  },
  {
    title: "Secure by Default",
    description:
      "Enterprise-grade security with end-to-end encryption and compliance built in.",
    icon: ShieldCheck,
  },
  {
    title: "Team Collaboration",
    description:
      "Work together in real-time with built-in collaboration tools and integrations.",
    icon: Users,
  },
];

export default function Home() {
  return (
    <main className="min-h-screen bg-[color:var(--background)] text-[color:var(--foreground)]">
      <header className="border-b border-[color:var(--border)]">
        <div className="mx-auto flex w-full max-w-6xl items-center justify-between px-6 py-5">
          <div className="flex items-center gap-3 text-lg font-semibold">
            <Sparkles className="h-6 w-6 text-[color:var(--primary)]" aria-hidden />
            <span>Acme</span>
          </div>
          <nav className="flex items-center gap-8 text-sm font-medium text-[color:var(--muted)]">
            <a className="transition-colors hover:text-[color:var(--foreground)]" href="#">
              Home
            </a>
            <a className="transition-colors hover:text-[color:var(--foreground)]" href="#">
              About
            </a>
            <a className="transition-colors hover:text-[color:var(--foreground)]" href="#">
              Contact
            </a>
          </nav>
        </div>
      </header>

      <section className="mx-auto flex w-full max-w-4xl flex-col items-center gap-6 px-6 py-20 text-center">
        <h1 className="text-4xl font-semibold tracking-tight text-[color:var(--foreground)] md:text-5xl">
          Build Better Products Faster
        </h1>
        <p className="max-w-2xl text-base text-[color:var(--muted)] md:text-lg">
          Streamline your workflow with our all-in-one platform. Ship features,
          track progress, and collaborate with your team seamlessly.
        </p>
        <Button className="px-8" size="lg">
          Get Started
        </Button>
      </section>

      <section className="border-t border-[color:var(--border)] bg-white/60 py-16">
        <div className="mx-auto w-full max-w-6xl px-6">
          <h2 className="text-center text-2xl font-semibold text-[color:var(--foreground)]">
            Everything You Need
          </h2>
          <div className="mt-10 grid gap-6 md:grid-cols-3">
            {features.map((feature) => {
              const Icon = feature.icon;
              return (
                <div
                  key={feature.title}
                  className="rounded-2xl border border-[color:var(--border)] bg-white p-6 shadow-sm"
                >
                  <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-blue-50 text-[color:var(--primary)]">
                    <Icon className="h-6 w-6" aria-hidden />
                  </div>
                  <h3 className="mt-4 text-lg font-semibold text-[color:var(--foreground)]">
                    {feature.title}
                  </h3>
                  <p className="mt-2 text-sm text-[color:var(--muted)]">
                    {feature.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <footer className="border-t border-[color:var(--border)] py-6">
        <div className="mx-auto w-full max-w-6xl px-6 text-center text-sm text-[color:var(--muted)]">
          © 2026 Acme. All rights reserved.
        </div>
      </footer>
    </main>
  );
}
