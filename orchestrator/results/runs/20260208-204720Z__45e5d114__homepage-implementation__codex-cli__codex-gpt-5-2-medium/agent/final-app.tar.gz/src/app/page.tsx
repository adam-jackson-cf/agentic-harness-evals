import { Bolt, Lock, Users } from "lucide-react";

import { Button } from "@/components/ui/button";

export type Feature = {
  title: string;
  description: string;
  icon: typeof Bolt;
};

const features: Feature[] = [
  {
    title: "Lightning Fast",
    description:
      "Deploy in seconds with our optimized infrastructure. No more waiting around.",
    icon: Bolt,
  },
  {
    title: "Secure by Default",
    description:
      "Enterprise-grade security with end-to-end encryption and compliance built in.",
    icon: Lock,
  },
  {
    title: "Team Collaboration",
    description:
      "Work together in real-time with built-in collaboration tools and integrations.",
    icon: Users,
  },
];

export default function Home() {
  return (
    <main className="min-h-screen bg-[var(--background)] text-[var(--foreground)]">
      <header className="border-b border-[var(--border)]">
        <div className="mx-auto flex w-full max-w-6xl items-center justify-between px-6 py-4">
          <div className="flex items-center gap-2">
            <span className="inline-flex h-8 w-8 items-center justify-center rounded-full bg-[var(--primary)] text-[var(--primary-foreground)]">
              <Bolt className="h-4 w-4" aria-hidden="true" />
            </span>
            <span className="text-lg font-semibold">Acme</span>
          </div>
          <nav className="flex items-center gap-6 text-sm font-medium text-[var(--muted)]">
            <a className="text-[var(--foreground)]" href="#home">
              Home
            </a>
            <a className="hover:text-[var(--foreground)]" href="#about">
              About
            </a>
            <a className="hover:text-[var(--foreground)]" href="#contact">
              Contact
            </a>
          </nav>
        </div>
      </header>

      <section
        id="home"
        className="mx-auto flex w-full max-w-3xl flex-col items-center px-6 py-20 text-center"
      >
        <h1 className="text-balance text-4xl font-semibold tracking-tight md:text-5xl">
          Build Better Products Faster
        </h1>
        <p className="mt-4 text-pretty text-base text-[var(--muted)] md:text-lg">
          Streamline your workflow with our all-in-one platform. Ship features,
          track progress, and collaborate with your team seamlessly.
        </p>
        <Button className="mt-8 h-11 px-6" size="lg">
          Get Started
        </Button>
      </section>

      <section
        id="about"
        className="border-t border-[var(--border)] bg-[var(--background)]"
      >
        <div className="mx-auto w-full max-w-6xl px-6 py-16">
          <h2 className="text-center text-2xl font-semibold">
            Everything You Need
          </h2>
          <div className="mt-10 grid gap-6 md:grid-cols-3">
            {features.map((feature) => {
              const Icon = feature.icon;
              return (
                <div
                  key={feature.title}
                  className="rounded-2xl border border-[var(--border)] bg-[var(--background)] p-6 shadow-sm"
                >
                  <span className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-[color:var(--primary)/0.08] text-[var(--primary)]">
                    <Icon className="h-5 w-5" aria-hidden="true" />
                  </span>
                  <h3 className="mt-4 text-lg font-semibold">
                    {feature.title}
                  </h3>
                  <p className="mt-2 text-sm text-[var(--muted)]">
                    {feature.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <footer
        id="contact"
        className="border-t border-[var(--border)] bg-[var(--background)]"
      >
        <div className="mx-auto flex w-full max-w-6xl items-center justify-between px-6 py-6 text-sm text-[var(--muted)]">
          <span>© 2026 Acme. All rights reserved.</span>
          <span>Contact: hello@acme.com</span>
        </div>
      </footer>
    </main>
  );
}
