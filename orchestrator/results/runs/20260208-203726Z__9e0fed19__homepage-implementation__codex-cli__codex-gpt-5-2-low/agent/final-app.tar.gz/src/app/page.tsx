import Link from "next/link";

import { Zap, ShieldCheck, Users } from "lucide-react";

import { Button } from "@/components/ui/button";

export type Feature = {
  title: string;
  description: string;
  icon: typeof Zap;
};

const features: Feature[] = [
  {
    title: "Lightning Fast",
    description:
      "Deploy in seconds with our optimized infrastructure. No more waiting around.",
    icon: Zap,
  },
  {
    title: "Secure by Default",
    description:
      "Enterprise-grade security with end-to-end encryption and compliance built in.",
    icon: ShieldCheck,
  },
  {
    title: "Team Collaboration",
    description:
      "Work together in real-time with built-in collaboration tools and integrations.",
    icon: Users,
  },
];

export default function Home() {
  return (
    <main className="min-h-screen bg-[var(--background)] text-[var(--foreground)]">
      <header className="border-b border-[var(--border)]">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-5">
          <div className="flex items-center gap-2 text-lg font-semibold">
            <Zap className="h-5 w-5 text-[var(--primary)]" aria-hidden="true" />
            <span>Acme</span>
          </div>
          <nav aria-label="Primary">
            <ul className="flex items-center gap-6 text-sm font-medium text-[var(--muted)]">
              <li>
                <Link className="hover:text-[var(--foreground)]" href="/">
                  Home
                </Link>
              </li>
              <li>
                <Link className="hover:text-[var(--foreground)]" href="#about">
                  About
                </Link>
              </li>
              <li>
                <Link className="hover:text-[var(--foreground)]" href="#contact">
                  Contact
                </Link>
              </li>
            </ul>
          </nav>
        </div>
      </header>

      <section className="px-6 py-20 text-center">
        <div className="mx-auto flex max-w-3xl flex-col items-center gap-6">
          <h1 className="text-4xl font-semibold tracking-tight text-[var(--foreground)] md:text-5xl">
            Build Better Products Faster
          </h1>
          <p className="text-base text-[var(--muted)] md:text-lg">
            Streamline your workflow with our all-in-one platform. Ship
            features, track progress, and collaborate with your team
            seamlessly.
          </p>
          <Button className="px-6 text-base">Get Started</Button>
        </div>
      </section>

      <section
        id="about"
        className="border-t border-[var(--border)] bg-white px-6 py-16"
      >
        <div className="mx-auto flex max-w-6xl flex-col items-center gap-10">
          <div className="text-center">
            <h2 className="text-2xl font-semibold text-[var(--foreground)]">
              Everything You Need
            </h2>
          </div>
          <div className="grid w-full gap-6 md:grid-cols-3">
            {features.map((feature) => {
              const Icon = feature.icon;
              return (
                <div
                  key={feature.title}
                  className="rounded-2xl border border-[var(--border)] bg-white p-6 shadow-sm"
                >
                  <div className="mb-4 flex h-10 w-10 items-center justify-center rounded-xl bg-blue-50">
                    <Icon
                      className="h-5 w-5 text-[var(--primary)]"
                      aria-hidden="true"
                    />
                  </div>
                  <h3 className="text-base font-semibold text-[var(--foreground)]">
                    {feature.title}
                  </h3>
                  <p className="mt-2 text-sm text-[var(--muted)]">
                    {feature.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <footer
        id="contact"
        className="border-t border-[var(--border)] px-6 py-6 text-center text-sm text-[var(--muted)]"
      >
        © {new Date().getFullYear()} Acme. All rights reserved.
      </footer>
    </main>
  );
}
