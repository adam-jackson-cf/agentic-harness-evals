import type { ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { ShieldCheck, Users, Zap } from "lucide-react";

type Feature = {
  title: string;
  description: string;
  icon: ReactNode;
};

const features: Feature[] = [
  {
    title: "Lightning Fast",
    description:
      "Deploy in seconds with our optimized infrastructure. No more waiting around.",
    icon: <Zap className="h-5 w-5 text-[color:var(--primary)]" aria-hidden="true" />,
  },
  {
    title: "Secure by Default",
    description:
      "Enterprise-grade security with end-to-end encryption and compliance built in.",
    icon: (
      <ShieldCheck
        className="h-5 w-5 text-[color:var(--primary)]"
        aria-hidden="true"
      />
    ),
  },
  {
    title: "Team Collaboration",
    description:
      "Work together in real-time with built-in collaboration tools and integrations.",
    icon: <Users className="h-5 w-5 text-[color:var(--primary)]" aria-hidden="true" />,
  },
];

export default function Home() {
  return (
    <main className="min-h-screen bg-[color:var(--background)]">
      <header className="border-b border-[color:var(--border)]">
        <div className="mx-auto flex w-full max-w-5xl items-center justify-between px-6 py-4">
          <div className="flex items-center gap-2 text-lg font-semibold">
            <Zap className="h-5 w-5 text-[color:var(--primary)]" aria-hidden="true" />
            <span>Acme</span>
          </div>
          <nav aria-label="Primary" className="flex items-center gap-6 text-sm">
            <a className="text-[color:var(--foreground)] hover:text-[color:var(--primary)]" href="#home">
              Home
            </a>
            <a className="text-[color:var(--foreground)] hover:text-[color:var(--primary)]" href="#about">
              About
            </a>
            <a className="text-[color:var(--foreground)] hover:text-[color:var(--primary)]" href="#contact">
              Contact
            </a>
          </nav>
        </div>
      </header>

      <section id="home" className="border-b border-[color:var(--border)]">
        <div className="mx-auto flex w-full max-w-3xl flex-col items-center px-6 py-20 text-center">
          <p className="text-sm font-semibold uppercase tracking-[0.2em] text-[color:var(--muted)]">
            Acme SaaS
          </p>
          <h1 className="mt-4 text-4xl font-semibold text-[color:var(--foreground)] sm:text-5xl">
            Build Better Products Faster
          </h1>
          <p className="mt-4 text-base text-[color:var(--muted)] sm:text-lg">
            Streamline your workflow with our all-in-one platform. Ship features, track
            progress, and collaborate with your team seamlessly.
          </p>
          <Button className="mt-8 px-8 py-6 text-base">Get Started</Button>
        </div>
      </section>

      <section id="about" className="py-20">
        <div className="mx-auto flex w-full max-w-5xl flex-col items-center gap-10 px-6">
          <div className="text-center">
            <h2 className="text-2xl font-semibold text-[color:var(--foreground)] sm:text-3xl">
              Everything You Need
            </h2>
            <p className="mt-2 text-sm text-[color:var(--muted)]">
              Powerful features designed to help teams ship confidently.
            </p>
          </div>
          <div className="grid w-full gap-6 md:grid-cols-3">
            {features.map((feature) => (
              <article
                key={feature.title}
                className="rounded-2xl border border-[color:var(--border)] bg-[color:var(--background)] p-6 shadow-sm"
              >
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[color:var(--border)]">
                  {feature.icon}
                </div>
                <h3 className="mt-4 text-lg font-semibold text-[color:var(--foreground)]">
                  {feature.title}
                </h3>
                <p className="mt-2 text-sm text-[color:var(--muted)]">
                  {feature.description}
                </p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <footer id="contact" className="border-t border-[color:var(--border)] py-6">
        <div className="mx-auto w-full max-w-5xl px-6 text-center text-sm text-[color:var(--muted)]">
          © 2026 Acme. All rights reserved.
        </div>
      </footer>
    </main>
  );
}
