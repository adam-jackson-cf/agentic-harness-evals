import { render, screen } from "@testing-library/react";
import Home from "@/app/page";

describe("Home page", () => {
  it("renders the header with logo and navigation links", () => {
    render(<Home />);

    expect(screen.getByText("Acme")).toBeInTheDocument();

    const navigation = screen.getByRole("navigation", { name: "Primary" });
    expect(navigation).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "Home" })).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "About" })).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "Contact" })).toBeInTheDocument();
  });

  it("renders the hero section and call to action", () => {
    render(<Home />);

    expect(
      screen.getByRole("heading", { name: "Build Better Products Faster" })
    ).toBeInTheDocument();
    expect(
      screen.getByText(
        /Streamline your workflow with our all-in-one platform/i
      )
    ).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Get Started" })).toBeInTheDocument();
  });

  it("renders the feature grid with three feature cards", () => {
    render(<Home />);

    expect(
      screen.getByRole("heading", { name: "Everything You Need" })
    ).toBeInTheDocument();

    const featureTitles = [
      "Lightning Fast",
      "Secure by Default",
      "Team Collaboration",
    ];

    featureTitles.forEach((title) => {
      expect(screen.getByRole("heading", { name: title })).toBeInTheDocument();
    });

    expect(screen.getAllByRole("article")).toHaveLength(3);
  });

  it("renders the footer", () => {
    render(<Home />);

    expect(
      screen.getByText("© 2026 Acme. All rights reserved.")
    ).toBeInTheDocument();
  });
});
