import { Shield, Users, Zap, type LucideIcon } from "lucide-react";

import { Button } from "@/components/ui/button";

export type Feature = {
  title: string;
  description: string;
  icon: LucideIcon;
};

const features: Feature[] = [
  {
    title: "Lightning Fast",
    description:
      "Deploy in seconds with our optimized infrastructure. No more waiting around.",
    icon: Zap,
  },
  {
    title: "Secure by Default",
    description:
      "Enterprise-grade security with end-to-end encryption and compliance built in.",
    icon: Shield,
  },
  {
    title: "Team Collaboration",
    description:
      "Work together in real-time with built-in collaboration tools and integrations.",
    icon: Users,
  },
];

export default function Home() {
  return (
    <div className="min-h-screen bg-[var(--background)] text-[var(--foreground)]">
      <header className="border-b border-[var(--border)]">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
          <div className="flex items-center gap-2 text-lg font-semibold">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-[color:color-mix(in srgb,var(--primary),white 85%)]">
              <Zap className="h-5 w-5 text-[var(--primary)]" aria-hidden />
            </span>
            <span>Acme</span>
          </div>
          <nav aria-label="Primary">
            <ul className="flex items-center gap-6 text-sm font-medium text-[var(--muted)]">
              <li>
                <a className="transition-colors hover:text-[var(--foreground)]" href="#">
                  Home
                </a>
              </li>
              <li>
                <a className="transition-colors hover:text-[var(--foreground)]" href="#">
                  About
                </a>
              </li>
              <li>
                <a className="transition-colors hover:text-[var(--foreground)]" href="#">
                  Contact
                </a>
              </li>
            </ul>
          </nav>
        </div>
      </header>

      <main>
        <section className="mx-auto max-w-4xl px-6 py-20 text-center">
          <h1 className="text-4xl font-semibold tracking-tight text-[var(--foreground)] md:text-5xl">
            Build Better Products Faster
          </h1>
          <p className="mx-auto mt-5 max-w-2xl text-base text-[var(--muted)] md:text-lg">
            Streamline your workflow with our all-in-one platform. Ship features,
            track progress, and collaborate with your team seamlessly.
          </p>
          <div className="mt-8 flex justify-center">
            <Button size="lg" className="rounded-xl px-8 text-base">
              Get Started
            </Button>
          </div>
        </section>

        <section className="border-t border-[var(--border)] bg-[var(--surface)] py-16">
          <div className="mx-auto max-w-6xl px-6">
            <div className="text-center">
              <h2 className="text-2xl font-semibold text-[var(--foreground)] md:text-3xl">
                Everything You Need
              </h2>
            </div>
            <div className="mt-10 grid gap-6 md:grid-cols-3">
              {features.map((feature) => {
                const Icon = feature.icon;
                return (
                  <article
                    key={feature.title}
                    className="rounded-2xl border border-[var(--border)] bg-[var(--background)] p-6 text-left shadow-sm"
                  >
                    <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-[color:color-mix(in srgb,var(--primary),white 85%)]">
                      <Icon className="h-5 w-5 text-[var(--primary)]" aria-hidden />
                    </div>
                    <h3 className="mt-4 text-lg font-semibold text-[var(--foreground)]">
                      {feature.title}
                    </h3>
                    <p className="mt-2 text-sm text-[var(--muted)]">
                      {feature.description}
                    </p>
                  </article>
                );
              })}
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-[var(--border)] py-6">
        <div className="mx-auto max-w-6xl px-6 text-center text-sm text-[var(--muted)]">
          © {new Date().getFullYear()} Acme. All rights reserved.
        </div>
      </footer>
    </div>
  );
}
