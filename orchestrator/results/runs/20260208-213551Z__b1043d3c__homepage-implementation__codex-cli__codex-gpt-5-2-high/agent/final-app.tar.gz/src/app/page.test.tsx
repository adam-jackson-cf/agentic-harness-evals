import { render, screen } from "@testing-library/react";

import Home from "@/app/page";

describe("Home page", () => {
  it("renders the header with logo and navigation links", () => {
    render(<Home />);

    expect(screen.getByText("Acme")).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "Home" })).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "About" })).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "Contact" })).toBeInTheDocument();
  });

  it("renders the hero content with a call-to-action", () => {
    render(<Home />);

    expect(
      screen.getByRole("heading", { name: "Build Better Products Faster" })
    ).toBeInTheDocument();
    expect(
      screen.getByText(
        /Streamline your workflow with our all-in-one platform\./i
      )
    ).toBeInTheDocument();
    expect(
      screen.getByRole("button", { name: "Get Started" })
    ).toBeInTheDocument();
  });

  it("renders the features grid", () => {
    render(<Home />);

    expect(
      screen.getByRole("heading", { name: "Everything You Need" })
    ).toBeInTheDocument();

    const featureHeadings = screen.getAllByRole("heading", { level: 3 });
    expect(featureHeadings).toHaveLength(3);
    expect(screen.getByText("Lightning Fast")).toBeInTheDocument();
    expect(screen.getByText("Secure by Default")).toBeInTheDocument();
    expect(screen.getByText("Team Collaboration")).toBeInTheDocument();
  });

  it("renders the footer copyright", () => {
    render(<Home />);

    const year = new Date().getFullYear();
    expect(
      screen.getByText(new RegExp(`© ${year} Acme`, "i"))
    ).toBeInTheDocument();
  });
});
