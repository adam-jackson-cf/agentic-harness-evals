import Link from "next/link";
import { Lock, Users, Zap } from "lucide-react";

import { Button } from "@/components/ui/button";

const features = [
  {
    title: "Lightning Fast",
    description: "Deploy in seconds with our optimized infrastructure.",
    icon: Zap,
  },
  {
    title: "Secure by Default",
    description: "Enterprise-grade security with end-to-end encryption.",
    icon: Lock,
  },
  {
    title: "Team Collaboration",
    description: "Work together in real-time with built-in tools.",
    icon: Users,
  },
] as const;

export default function Home() {
  return (
    <div className="min-h-screen bg-[var(--background)] text-[var(--foreground)]">
      <header className="border-b border-[var(--border)]">
        <div className="mx-auto flex w-full max-w-6xl items-center justify-between px-6 py-5">
          <div className="flex items-center gap-2 text-lg font-semibold">
            <Zap className="h-5 w-5 text-[var(--primary)]" aria-hidden="true" />
            <span>Acme</span>
          </div>
          <nav aria-label="Primary navigation">
            <ul className="flex items-center gap-6 text-sm font-medium text-[var(--muted)]">
              <li>
                <Link className="transition-colors hover:text-[var(--foreground)]" href="/">
                  Home
                </Link>
              </li>
              <li>
                <Link className="transition-colors hover:text-[var(--foreground)]" href="/about">
                  About
                </Link>
              </li>
              <li>
                <Link className="transition-colors hover:text-[var(--foreground)]" href="/contact">
                  Contact
                </Link>
              </li>
            </ul>
          </nav>
        </div>
      </header>

      <main>
        <section className="px-6 py-20">
          <div className="mx-auto flex w-full max-w-3xl flex-col items-center text-center">
            <p className="text-sm font-semibold uppercase tracking-[0.2em] text-[var(--muted)]">
              Product Velocity
            </p>
            <h1 className="mt-4 text-4xl font-semibold tracking-tight text-[var(--foreground)] sm:text-5xl">
              Build Better Products Faster
            </h1>
            <p className="mt-4 text-base text-[var(--muted)] sm:text-lg">
              Streamline your workflow with our all-in-one platform. Ship features, track
              progress, and collaborate with your team seamlessly.
            </p>
            <Button className="mt-8" size="lg">
              Get Started
            </Button>
          </div>
        </section>

        <section className="border-t border-[var(--border)] bg-[var(--background)] px-6 py-16">
          <div className="mx-auto w-full max-w-6xl">
            <div className="text-center">
              <h2 className="text-2xl font-semibold text-[var(--foreground)] sm:text-3xl">
                Everything You Need
              </h2>
              <p className="mt-2 text-sm text-[var(--muted)] sm:text-base">
                Powerful features that help your team build confidently.
              </p>
            </div>

            <div className="mt-10 grid gap-6 md:grid-cols-3">
              {features.map((feature) => {
                const Icon = feature.icon;
                return (
                  <article
                    className="rounded-2xl border border-[var(--border)] bg-[var(--background)] p-6 shadow-sm"
                    key={feature.title}
                  >
                    <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-blue-50 text-[var(--primary)]">
                      <Icon className="h-5 w-5" aria-hidden="true" />
                    </div>
                    <h3 className="mt-4 text-lg font-semibold text-[var(--foreground)]">
                      {feature.title}
                    </h3>
                    <p className="mt-2 text-sm text-[var(--muted)]">
                      {feature.description}
                    </p>
                  </article>
                );
              })}
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-[var(--border)] px-6 py-6">
        <div className="mx-auto w-full max-w-6xl text-center text-sm text-[var(--muted)]">
          © {new Date().getFullYear()} Acme. All rights reserved.
        </div>
      </footer>
    </div>
  );
}
