import type { ComponentType, SVGProps } from "react";

import { ShieldCheck, Users, Zap } from "lucide-react";

import { Button } from "@/components/ui/button";

export type Feature = {
  title: string;
  description: string;
  icon: ComponentType<SVGProps<SVGSVGElement>>;
};

const features: Feature[] = [
  {
    title: "Lightning Fast",
    description:
      "Deploy in seconds with our optimized infrastructure. No more waiting around.",
    icon: Zap,
  },
  {
    title: "Secure by Default",
    description:
      "Enterprise-grade security with end-to-end encryption and compliance built in.",
    icon: ShieldCheck,
  },
  {
    title: "Team Collaboration",
    description:
      "Work together in real-time with built-in collaboration tools and integrations.",
    icon: Users,
  },
];

export default function Home() {
  const currentYear = new Date().getFullYear();

  return (
    <div className="min-h-screen bg-[color:var(--background)] text-[color:var(--foreground)]">
      <header className="border-b border-[color:var(--border)]">
        <div className="mx-auto flex w-full max-w-6xl items-center justify-between px-6 py-4">
          <div className="flex items-center gap-2 text-lg font-semibold">
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-[color:var(--border)] text-[color:var(--primary)]">
              <Zap aria-hidden className="h-4 w-4" />
            </span>
            <span>Acme</span>
          </div>
          <nav className="flex items-center gap-6 text-sm font-medium text-[color:var(--muted)]">
            <a className="transition-colors hover:text-[color:var(--foreground)]" href="#">
              Home
            </a>
            <a className="transition-colors hover:text-[color:var(--foreground)]" href="#about">
              About
            </a>
            <a className="transition-colors hover:text-[color:var(--foreground)]" href="#contact">
              Contact
            </a>
          </nav>
        </div>
      </header>

      <main>
        <section className="px-6 py-20 text-center">
          <div className="mx-auto flex w-full max-w-3xl flex-col items-center gap-6">
            <div className="space-y-4">
              <p className="text-sm font-semibold uppercase tracking-[0.2em] text-[color:var(--muted)]">
                SaaS Platform
              </p>
              <h1 className="text-4xl font-semibold tracking-tight sm:text-5xl">
                Build Better Products Faster
              </h1>
              <p className="text-base text-[color:var(--muted)] sm:text-lg">
                Streamline your workflow with our all-in-one platform. Ship features,
                track progress, and collaborate with your team seamlessly.
              </p>
            </div>
            <Button size="lg" type="button">
              Get Started
            </Button>
          </div>
        </section>

        <section className="border-t border-[color:var(--border)] bg-[color:var(--background)] px-6 py-20">
          <div className="mx-auto w-full max-w-6xl">
            <div className="text-center">
              <h2 className="text-2xl font-semibold sm:text-3xl">Everything You Need</h2>
              <p className="mt-3 text-[color:var(--muted)]">
                Tools that keep your product team aligned, focused, and shipping.
              </p>
            </div>
            <div className="mt-12 grid gap-6 md:grid-cols-3">
              {features.map((feature) => {
                const Icon = feature.icon;

                return (
                  <div
                    key={feature.title}
                    className="rounded-2xl border border-[color:var(--border)] bg-[color:var(--background)] p-6 shadow-sm"
                  >
                    <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-[color:var(--border)] text-[color:var(--primary)]">
                      <Icon aria-hidden className="h-5 w-5" />
                    </div>
                    <h3 className="mt-6 text-lg font-semibold">{feature.title}</h3>
                    <p className="mt-2 text-sm text-[color:var(--muted)]">
                      {feature.description}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-[color:var(--border)] px-6 py-6 text-center text-sm text-[color:var(--muted)]">
        &copy; {currentYear} Acme. All rights reserved.
      </footer>
    </div>
  );
}
