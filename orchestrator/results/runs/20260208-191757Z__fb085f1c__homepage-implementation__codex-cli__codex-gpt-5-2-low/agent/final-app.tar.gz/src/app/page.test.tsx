import { render, screen, within } from "@testing-library/react";

import Home from "@/app/page";

describe("Home page", () => {
  it("renders the header with logo and navigation links", () => {
    render(<Home />);

    expect(screen.getByText("Acme")).toBeInTheDocument();

    const nav = screen.getByRole("navigation");
    expect(within(nav).getByText("Home")).toBeInTheDocument();
    expect(within(nav).getByText("About")).toBeInTheDocument();
    expect(within(nav).getByText("Contact")).toBeInTheDocument();
  });

  it("renders the hero section with headline, subheadline, and CTA", () => {
    render(<Home />);

    expect(
      screen.getByRole("heading", {
        level: 1,
        name: "Build Better Products Faster",
      })
    ).toBeInTheDocument();

    expect(
      screen.getByText(
        /Streamline your workflow with our all-in-one platform/i
      )
    ).toBeInTheDocument();

    expect(
      screen.getByRole("button", { name: "Get Started" })
    ).toBeInTheDocument();
  });

  it("renders three feature cards", () => {
    render(<Home />);

    const featureSection = screen.getByRole("heading", {
      level: 2,
      name: "Everything You Need",
    }).parentElement;

    if (!featureSection) {
      throw new Error("Feature section not found");
    }

    const cards = within(featureSection.parentElement ?? featureSection).getAllByRole(
      "heading",
      { level: 3 }
    );

    expect(cards).toHaveLength(3);
  });

  it("renders the footer with copyright text", () => {
    render(<Home />);

    expect(
      screen.getByText("© 2026 Acme. All rights reserved.")
    ).toBeInTheDocument();
  });
});
