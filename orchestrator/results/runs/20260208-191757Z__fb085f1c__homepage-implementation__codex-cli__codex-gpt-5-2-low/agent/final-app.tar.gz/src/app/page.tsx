import { ShieldCheck, Users, Zap } from "lucide-react";

import { Button } from "@/components/ui/button";

const features = [
  {
    title: "Lightning Fast",
    description:
      "Deploy in seconds with our optimized infrastructure. No more waiting around.",
    Icon: Zap,
  },
  {
    title: "Secure by Default",
    description:
      "Enterprise-grade security with end-to-end encryption and compliance built in.",
    Icon: ShieldCheck,
  },
  {
    title: "Team Collaboration",
    description:
      "Work together in real-time with built-in collaboration tools and integrations.",
    Icon: Users,
  },
];

export type Feature = (typeof features)[number];

export default function Home() {
  return (
    <main className="min-h-screen bg-[var(--background)] text-[var(--foreground)]">
      <header className="border-b border-[var(--border)]">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-5">
          <div className="flex items-center gap-2 text-lg font-semibold">
            <span className="flex h-9 w-9 items-center justify-center rounded-full bg-blue-50 text-[var(--primary)]">
              <Zap className="h-5 w-5" aria-hidden="true" />
            </span>
            <span>Acme</span>
          </div>
          <nav className="flex items-center gap-8 text-sm font-medium text-[var(--muted)]">
            <a className="transition-colors hover:text-[var(--foreground)]" href="#">
              Home
            </a>
            <a className="transition-colors hover:text-[var(--foreground)]" href="#">
              About
            </a>
            <a className="transition-colors hover:text-[var(--foreground)]" href="#">
              Contact
            </a>
          </nav>
        </div>
      </header>

      <section className="border-b border-transparent bg-white">
        <div className="mx-auto flex max-w-4xl flex-col items-center px-6 py-24 text-center">
          <p className="mb-4 text-sm font-semibold uppercase tracking-[0.2em] text-[var(--muted-foreground)]">
            Product workflow
          </p>
          <h1 className="text-4xl font-semibold leading-tight tracking-tight text-[var(--foreground)] sm:text-5xl">
            Build Better Products Faster
          </h1>
          <p className="mt-5 max-w-2xl text-base text-[var(--muted)] sm:text-lg">
            Streamline your workflow with our all-in-one platform. Ship features,
            track progress, and collaborate with your team seamlessly.
          </p>
          <Button className="mt-8 h-12 px-8 text-base">Get Started</Button>
        </div>
      </section>

      <section className="bg-slate-50">
        <div className="mx-auto max-w-6xl px-6 py-20">
          <div className="text-center">
            <p className="text-xs font-semibold uppercase tracking-[0.3em] text-[var(--muted-foreground)]">
              Features
            </p>
            <h2 className="mt-3 text-3xl font-semibold text-[var(--foreground)]">
              Everything You Need
            </h2>
          </div>
          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {features.map(({ title, description, Icon }) => (
              <div
                key={title}
                className="rounded-2xl border border-[var(--border)] bg-white p-6 shadow-sm"
              >
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-blue-50 text-[var(--primary)]">
                  <Icon className="h-5 w-5" aria-hidden="true" />
                </div>
                <h3 className="mt-4 text-lg font-semibold text-[var(--foreground)]">
                  {title}
                </h3>
                <p className="mt-2 text-sm text-[var(--muted)]">{description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <footer className="border-t border-[var(--border)] bg-white">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-6 text-sm text-[var(--muted)]">
          <span>© 2026 Acme. All rights reserved.</span>
          <span>Built for modern teams.</span>
        </div>
      </footer>
    </main>
  );
}
