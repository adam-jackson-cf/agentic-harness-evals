import { ShieldCheck, Users, Zap } from "lucide-react";
import type { LucideIcon } from "lucide-react";

import { Button } from "@/components/ui/button";

export type Feature = {
  description: string;
  icon: LucideIcon;
  title: string;
};

const features: Feature[] = [
  {
    title: "Lightning Fast",
    description:
      "Deploy in seconds with our optimized infrastructure. No more waiting around.",
    icon: Zap,
  },
  {
    title: "Secure by Default",
    description:
      "Enterprise-grade security with end-to-end encryption and compliance built in.",
    icon: ShieldCheck,
  },
  {
    title: "Team Collaboration",
    description:
      "Work together in real-time with built-in collaboration tools and integrations.",
    icon: Users,
  },
];

export default function Home() {
  return (
    <main className="min-h-screen bg-[var(--background)] text-[var(--foreground)]">
      <header className="border-b border-[var(--border)]">
        <div className="mx-auto flex w-full max-w-6xl items-center justify-between px-6 py-4">
          <div className="flex items-center gap-2">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-50 text-[var(--primary)]">
              <Zap aria-hidden="true" className="h-5 w-5" />
            </span>
            <span className="text-lg font-semibold">Acme</span>
          </div>
          <nav aria-label="Primary" className="flex items-center gap-6 text-sm">
            {["Home", "About", "Contact"].map((item) => (
              <a
                className="text-[var(--muted)] transition hover:text-[var(--foreground)]"
                href={`#${item.toLowerCase()}`}
                key={item}
              >
                {item}
              </a>
            ))}
          </nav>
        </div>
      </header>

      <section
        className="mx-auto flex w-full max-w-3xl flex-col items-center gap-6 px-6 py-20 text-center"
        id="home"
      >
        <div className="space-y-4">
          <p className="text-sm font-semibold uppercase tracking-[0.2em] text-[var(--muted)]">
            Acme Cloud Suite
          </p>
          <h1 className="text-balance text-4xl font-semibold text-[var(--foreground)] sm:text-5xl">
            Build Better Products Faster
          </h1>
          <p className="text-balance text-lg text-[var(--muted)]">
            Streamline your workflow with our all-in-one platform. Ship
            features, track progress, and collaborate with your team seamlessly.
          </p>
        </div>
        <Button size="lg">Get Started</Button>
      </section>

      <section
        className="bg-gray-50 py-16"
        id="about"
        aria-labelledby="features-title"
      >
        <div className="mx-auto w-full max-w-6xl px-6">
          <div className="text-center">
            <p className="text-sm font-semibold uppercase tracking-[0.2em] text-[var(--muted)]">
              Features
            </p>
            <h2
              className="mt-3 text-3xl font-semibold text-[var(--foreground)]"
              id="features-title"
            >
              Everything You Need
            </h2>
          </div>
          <ul className="mt-10 grid gap-6 md:grid-cols-3">
            {features.map((feature) => {
              const Icon = feature.icon;

              return (
                <li
                  className="rounded-2xl border border-[var(--border)] bg-white p-6 shadow-sm"
                  key={feature.title}
                >
                  <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-blue-50 text-[var(--primary)]">
                    <Icon aria-hidden="true" className="h-6 w-6" />
                  </div>
                  <h3 className="mt-6 text-lg font-semibold">
                    {feature.title}
                  </h3>
                  <p className="mt-3 text-sm leading-relaxed text-[var(--muted)]">
                    {feature.description}
                  </p>
                </li>
              );
            })}
          </ul>
        </div>
      </section>

      <footer className="border-t border-[var(--border)]">
        <div className="mx-auto flex w-full max-w-6xl items-center justify-between px-6 py-6 text-sm text-[var(--muted)]">
          <p>Copyright © {new Date().getFullYear()} Acme</p>
          <p id="contact">All rights reserved.</p>
        </div>
      </footer>
    </main>
  );
}
