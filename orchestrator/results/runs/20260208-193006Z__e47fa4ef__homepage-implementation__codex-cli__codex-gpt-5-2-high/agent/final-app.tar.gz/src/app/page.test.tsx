import { render, screen, within } from "@testing-library/react";
import { describe, expect, it } from "vitest";

import Home from "@/app/page";

describe("Home page", () => {
  it("renders the header with logo and navigation links", () => {
    render(<Home />);

    expect(screen.getByText("Acme")).toBeInTheDocument();

    const navigation = screen.getByRole("navigation", { name: "Primary" });
    const navLinks = ["Home", "About", "Contact"];

    navLinks.forEach((link) => {
      expect(
        within(navigation).getByRole("link", { name: link })
      ).toBeInTheDocument();
    });
  });

  it("shows the hero content with call to action", () => {
    render(<Home />);

    expect(
      screen.getByRole("heading", { name: "Build Better Products Faster" })
    ).toBeInTheDocument();
    expect(
      screen.getByText(
        /Streamline your workflow with our all-in-one platform/i
      )
    ).toBeInTheDocument();
    expect(
      screen.getByRole("button", { name: "Get Started" })
    ).toBeInTheDocument();
  });

  it("renders the features grid with three features", () => {
    render(<Home />);

    expect(
      screen.getByRole("heading", { name: "Everything You Need" })
    ).toBeInTheDocument();

    const featureList = screen.getByRole("list");
    const featureItems = within(featureList).getAllByRole("listitem");

    expect(featureItems).toHaveLength(3);

    ["Lightning Fast", "Secure by Default", "Team Collaboration"].forEach(
      (title) => {
        expect(screen.getByText(title)).toBeInTheDocument();
      }
    );
  });

  it("includes the footer copyright text", () => {
    render(<Home />);

    const year = new Date().getFullYear().toString();
    expect(
      screen.getByText(new RegExp(`Copyright © ${year} Acme`, "i"))
    ).toBeInTheDocument();
    expect(screen.getByText(/All rights reserved/i)).toBeInTheDocument();
  });
});
