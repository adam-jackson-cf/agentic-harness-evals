import { render, screen } from "@testing-library/react";

import Home from "@/app/page";

describe("Home page", () => {
  it("renders the header with logo and navigation links", () => {
    render(<Home />);

    expect(screen.getByText("Acme")).toBeInTheDocument();
    expect(screen.getByRole("link", { name: "Home" })).toHaveAttribute(
      "href",
      "#home"
    );
    expect(screen.getByRole("link", { name: "About" })).toHaveAttribute(
      "href",
      "#about"
    );
    expect(screen.getByRole("link", { name: "Contact" })).toHaveAttribute(
      "href",
      "#contact"
    );
  });

  it("renders the hero content and call-to-action", () => {
    render(<Home />);

    expect(
      screen.getByRole("heading", { name: "Build Better Products Faster" })
    ).toBeInTheDocument();
    expect(
      screen.getByText(
        /streamline your workflow with our all-in-one platform/i
      )
    ).toBeInTheDocument();
    expect(
      screen.getByRole("button", { name: "Get Started" })
    ).toBeInTheDocument();
  });

  it("renders the features grid", () => {
    render(<Home />);

    expect(
      screen.getByRole("heading", { name: "Everything You Need" })
    ).toBeInTheDocument();

    const featureCards = screen.getAllByRole("article");
    expect(featureCards).toHaveLength(3);

    ["Lightning Fast", "Secure by Default", "Team Collaboration"].forEach(
      (feature) => {
        expect(screen.getByRole("heading", { name: feature })).toBeInTheDocument();
      }
    );
  });

  it("renders the footer copyright", () => {
    render(<Home />);

    expect(
      screen.getByText("© 2026 Acme. All rights reserved.")
    ).toBeInTheDocument();
  });
});
