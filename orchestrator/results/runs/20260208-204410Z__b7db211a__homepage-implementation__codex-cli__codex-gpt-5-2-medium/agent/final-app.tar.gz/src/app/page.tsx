import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { ShieldCheck, Users, Zap } from "lucide-react";

export type Feature = {
  title: string;
  description: string;
  icon: typeof Zap;
};

const features: Feature[] = [
  {
    title: "Lightning Fast",
    description:
      "Deploy in seconds with our optimized infrastructure. No more waiting around.",
    icon: Zap,
  },
  {
    title: "Secure by Default",
    description:
      "Enterprise-grade security with end-to-end encryption and compliance built in.",
    icon: ShieldCheck,
  },
  {
    title: "Team Collaboration",
    description:
      "Work together in real-time with built-in collaboration tools and integrations.",
    icon: Users,
  },
];

const navLinks = ["Home", "About", "Contact"] as const;

export default function Home() {
  return (
    <main className="min-h-screen bg-[var(--background)] text-[var(--foreground)]">
      <header className="border-b border-[var(--border)]">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-5">
          <div className="flex items-center gap-2 text-lg font-semibold">
            <span
              aria-hidden="true"
              className="flex h-9 w-9 items-center justify-center rounded-full bg-blue-50 text-[var(--primary)]"
            >
              <Zap className="h-5 w-5" />
            </span>
            <span>Acme</span>
          </div>
          <nav aria-label="Primary">
            <ul className="flex items-center gap-8 text-sm font-medium text-[var(--muted)]">
              {navLinks.map((label) => (
                <li key={label}>
                  <a
                    className="transition-colors hover:text-[var(--foreground)]"
                    href={`#${label.toLowerCase()}`}
                  >
                    {label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>
        </div>
      </header>

      <section
        className="mx-auto flex max-w-4xl flex-col items-center gap-6 px-6 py-20 text-center"
        id="home"
      >
        <h1 className="text-4xl font-semibold tracking-tight text-[var(--foreground)] sm:text-5xl">
          Build Better Products Faster
        </h1>
        <p className="max-w-2xl text-base leading-relaxed text-[var(--muted)] sm:text-lg">
          Streamline your workflow with our all-in-one platform. Ship features,
          track progress, and collaborate with your team seamlessly.
        </p>
        <Button className="h-11 rounded-lg px-8 text-base font-semibold">
          Get Started
        </Button>
      </section>

      <section
        className="border-t border-[var(--border)] bg-[#f9fafb] py-16"
        id="about"
      >
        <div className="mx-auto max-w-6xl px-6">
          <div className="mb-12 text-center">
            <h2 className="text-3xl font-semibold text-[var(--foreground)]">
              Everything You Need
            </h2>
          </div>
          <div className="grid gap-6 md:grid-cols-3">
            {features.map((feature) => {
              const Icon = feature.icon;
              return (
                <article
                  className="rounded-2xl border border-[var(--border)] bg-white p-6 shadow-sm"
                  key={feature.title}
                >
                  <div
                    className={cn(
                      "mb-4 inline-flex h-10 w-10 items-center justify-center rounded-xl",
                      "bg-blue-50 text-[var(--primary)]"
                    )}
                  >
                    <Icon className="h-5 w-5" aria-hidden="true" />
                  </div>
                  <h3 className="mb-2 text-lg font-semibold text-[var(--foreground)]">
                    {feature.title}
                  </h3>
                  <p className="text-sm leading-relaxed text-[var(--muted)]">
                    {feature.description}
                  </p>
                </article>
              );
            })}
          </div>
        </div>
      </section>

      <footer
        className="border-t border-[var(--border)] py-6"
        id="contact"
      >
        <div className="mx-auto max-w-6xl px-6 text-center text-sm text-[var(--muted)]">
          © 2026 Acme. All rights reserved.
        </div>
      </footer>
    </main>
  );
}
