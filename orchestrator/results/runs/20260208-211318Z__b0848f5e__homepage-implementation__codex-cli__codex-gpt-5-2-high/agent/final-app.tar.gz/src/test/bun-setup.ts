import "@testing-library/jest-dom";
import { JSDOM } from "jsdom";

type GlobalWithDom = typeof globalThis & {
  window: Window;
  document: Document;
  navigator: Navigator;
};

const dom = new JSDOM("<!doctype html><html><body></body></html>", {
  url: "http://localhost",
});

const globalWithDom = globalThis as GlobalWithDom;

globalWithDom.window = dom.window as unknown as Window;
globalWithDom.document = dom.window.document;
globalWithDom.navigator = dom.window.navigator;

Object.getOwnPropertyNames(dom.window).forEach((property) => {
  if (property in globalThis) {
    return;
  }

  (globalThis as Record<string, unknown>)[property] =
    dom.window[property as keyof Window];
});

globalThis.requestAnimationFrame ??= (callback: FrameRequestCallback) =>
  setTimeout(callback, 0);

globalThis.cancelAnimationFrame ??= (handle: number) =>
  clearTimeout(handle);
