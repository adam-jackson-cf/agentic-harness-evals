import type { ElementType } from "react";

import { ShieldCheck, Users, Zap } from "lucide-react";

import { Button } from "@/components/ui/button";

export type Feature = {
  title: string;
  description: string;
  icon: ElementType;
};

const features: Feature[] = [
  {
    title: "Lightning Fast",
    description:
      "Deploy in seconds with our optimized infrastructure. No more waiting around.",
    icon: Zap,
  },
  {
    title: "Secure by Default",
    description:
      "Enterprise-grade security with end-to-end encryption and compliance built in.",
    icon: ShieldCheck,
  },
  {
    title: "Team Collaboration",
    description:
      "Work together in real-time with built-in collaboration tools and integrations.",
    icon: Users,
  },
];

const navLinks = ["Home", "About", "Contact"] as const;

export default function Home() {
  const currentYear = new Date().getFullYear();

  return (
    <div className="flex min-h-screen flex-col bg-[var(--background)] text-[var(--foreground)]">
      <header className="border-b border-[var(--border)]">
        <div className="mx-auto flex w-full max-w-6xl items-center justify-between px-6 py-4">
          <div className="flex items-center gap-2 text-lg font-semibold">
            <span className="flex h-8 w-8 items-center justify-center rounded-md bg-blue-50 text-[var(--primary)]">
              <Zap className="h-5 w-5" aria-hidden="true" />
            </span>
            <span>Acme</span>
          </div>
          <nav className="flex items-center gap-6 text-sm font-medium text-[var(--muted)]">
            {navLinks.map((link) => (
              <a
                className="transition-colors hover:text-[var(--foreground)]"
                href={`#${link.toLowerCase()}`}
                key={link}
              >
                {link}
              </a>
            ))}
          </nav>
        </div>
      </header>

      <main className="flex-1">
        <section className="px-6 py-20" id="home">
          <div className="mx-auto flex w-full max-w-3xl flex-col items-center gap-6 text-center">
            <p className="text-sm font-semibold uppercase tracking-[0.2em] text-[var(--muted-foreground)]">
              Modern SaaS Platform
            </p>
            <h1 className="text-4xl font-semibold tracking-tight sm:text-5xl">
              Build Better Products Faster
            </h1>
            <p className="text-base leading-relaxed text-[var(--muted)] sm:text-lg">
              Streamline your workflow with our all-in-one platform. Ship features,
              track progress, and collaborate with your team seamlessly.
            </p>
            <Button className="px-8" size="lg">
              Get Started
            </Button>
          </div>
        </section>

        <section
          className="border-t border-[var(--border)] bg-[var(--surface)] px-6 py-16"
          id="about"
        >
          <div className="mx-auto w-full max-w-6xl">
            <div className="text-center">
              <h2 className="text-3xl font-semibold">Everything You Need</h2>
              <p className="mt-2 text-sm text-[var(--muted)]">
                Powerful features designed to help your team deliver faster.
              </p>
            </div>
            <div className="mt-10 grid gap-6 md:grid-cols-3">
              {features.map((feature) => {
                const Icon = feature.icon;
                return (
                  <article
                    className="flex h-full flex-col gap-4 rounded-xl border border-[var(--border)] bg-[var(--background)] p-6 shadow-sm"
                    data-testid="feature-card"
                    key={feature.title}
                  >
                    <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-[var(--primary)]">
                      <Icon className="h-5 w-5" aria-hidden="true" />
                    </span>
                    <div>
                      <h3 className="text-lg font-semibold">{feature.title}</h3>
                      <p className="mt-2 text-sm leading-relaxed text-[var(--muted)]">
                        {feature.description}
                      </p>
                    </div>
                  </article>
                );
              })}
            </div>
          </div>
        </section>
      </main>

      <footer
        className="border-t border-[var(--border)] px-6 py-6 text-center text-sm text-[var(--muted)]"
        id="contact"
      >
        <p>Copyright {currentYear} Acme. All rights reserved.</p>
      </footer>
    </div>
  );
}
