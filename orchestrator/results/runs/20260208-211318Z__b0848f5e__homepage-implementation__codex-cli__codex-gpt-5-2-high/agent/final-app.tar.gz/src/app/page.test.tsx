import { render, screen } from "@testing-library/react";

import Home from "@/app/page";

describe("Homepage", () => {
  it("renders the header with logo and navigation links", () => {
    render(<Home />);

    expect(screen.getByText("Acme")).toBeInTheDocument();

    ["Home", "About", "Contact"].forEach((label) => {
      expect(screen.getByRole("link", { name: label })).toBeInTheDocument();
    });
  });

  it("renders the hero headline, subheadline, and call-to-action", () => {
    render(<Home />);

    expect(
      screen.getByRole("heading", { name: /build better products faster/i })
    ).toBeInTheDocument();
    expect(
      screen.getByText(
        /streamline your workflow with our all-in-one platform/i
      )
    ).toBeInTheDocument();
    expect(
      screen.getByRole("button", { name: /get started/i })
    ).toBeInTheDocument();
  });

  it("shows a features section with three feature cards", () => {
    render(<Home />);

    const cards = screen.getAllByTestId("feature-card");
    expect(cards).toHaveLength(3);

    ["Lightning Fast", "Secure by Default", "Team Collaboration"].forEach(
      (feature) => {
        expect(
          screen.getByRole("heading", { name: feature })
        ).toBeInTheDocument();
      }
    );
  });

  it("renders the footer with copyright text", () => {
    render(<Home />);

    const year = new Date().getFullYear();
    expect(
      screen.getByText(new RegExp(`Copyright ${year} Acme`, "i"))
    ).toBeInTheDocument();
  });
});
